class acc
{
    char tyu(char a)
    {
        return ++a;
    }
}