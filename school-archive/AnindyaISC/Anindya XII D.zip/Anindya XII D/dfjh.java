class dfjh
{
    void main(int a)
    {
        for(int i=0;i<a;i++)
        System.out.println(i+1);
    }
}