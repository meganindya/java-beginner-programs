class chk
{
    int rand()
    {
        return (int)(Math.ceil(Math.random()*10));
    }
}